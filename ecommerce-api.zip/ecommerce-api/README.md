# E-Commerce API

A simple Node.js eCommerce REST API using Express and MongoDB.

## Features
- JWT Authentication
- Product Management
- Order Management

## Run
```bash
npm install
npm run dev
```
